"""Shanghai community health centre coverage from audited official data.

Default: reproduce results from health_centres.geojson, with no network.
--prepare-only: rebuild audited points from cached public official sources in tmp.
Requires the two existing analysis folders, numpy/scipy/shapely/pyproj.
"""
import sys,re,json,math,unicodedata,collections,argparse
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE.parent/'公共设施覆盖地图'))
from analyze_coverage import (read,write,DM,DISTRICTS,CENTRAL,REGIONS,MASKS,
    shapely,np,shape,mapping,Point,transform,TO_M,TO_LL,cKDTree,grid_distances)
sys.path.insert(0,str(HERE.parent/'覆盖折中点分析'))
from analyze_tradeoffs import from_distances,fixed_upper
from analyze_canteens import gcj_to_wgs
REGISTRY_URL='https://wsjkw.sh.gov.cn/fwjg/20180601/0012-55892.html'
MAP_URL='https://www.shanghai-map.net/shtdt/index.html'
PRIMARY={'14':'淮海中路966号','15':'罗秀路1139号','22':'华泾路507号','28':'大统路168号',
 '39':'华阳路292号','40':'愚园路744弄1号','42':'长宁路1700号','46':'虹井路996号','48':'淞虹路507号',
 '137':'昌里路360号','183':'延寿路50弄1号','188':'龙马路633弄1号','189':'滨亭路216弄1号','194':'西静路367号'}

def clean(s):return re.sub(r'[\s,，、;；。·\[\]【】]','',unicodedata.normalize('NFKC',str(s)))
def addr(s,district=''):
 s=clean(s)
 for p in ['上海市',district,'闵行区','青浦区']:
  if p and s.startswith(p):s=s[len(p):]
 return s
def name(s,district):
 s=re.sub(r'\(.*?\)','',clean(s))
 for p in ['上海市',district]:
  if s.startswith(p):s=s[len(p):]
 return s.replace('街道','').replace('镇','')
def unpack(j):
 s=j.get('d','')
 if '@@' not in s:return []
 return json.loads(s.split('@@',1)[1])
def acceptable_address(row,p):
 a=addr(row['address'],row['district']);b=addr(p['ADDR'],row['district'])
 primary=PRIMARY.get(row['id'])
 if primary and b==addr(primary,row['district']):return '主要门诊/院址门牌一致',True
 if b and a==b:return '地址一致',True
 # Exact listed address component, followed only by a building/floor annotation.
 if b and b in a and re.search(r'(号|弄\d+号)$',b):return '官网多地址中的一个明确院址',False
 manual={'43':('天山四村122号','娄山关路天山四村122号'),
   '107':('少年村路218号甲','少年村路218号'),
   '125':('民主街97号','南翔民主街97号'),
   '184':('共青路1237号','新浜共青路1237号'),
   '198':('张漕公路118号','张漕路118号'),
   '206':('沈巷曲池路39号','曲池路39号'),
   '211':('新桥路1195弄1号','青浦新桥路1195弄1号'),
   '213':('新建西路160号A座','新建西路160号'),
   '226':('泰青路356号','泰青公路356号'),
   '230':('宏海公路4235号','宏海公路4235-4237号'),
   '231':('白钥村1269号','建设镇白钥村1269号')}
 if row['id'] in manual and (a,b)==manual[row['id']]:return '地址附号/乡镇前缀/道路简称人工核对',False
 return '',False

def prepare():
 rows=read(ROOT/'tmp'/'health-matches.json');features=[]
 supplements={x['id']:x for x in read(ROOT/'tmp'/'health-location-supplements.json')}
 for r in rows:
  candidates=[]
  for p in r['name_candidates']+r['address_candidates']:
   candidates.append({**p,'source_kind':'官方专题POI','query':None})
  for kind in ['address','name']:
   path=ROOT/'tmp'/'health-location-search'/(r['id']+'-'+kind+'.json')
   if path.exists():
    q=read(path)
    candidates.extend({**p,'source_kind':'官方地图检索','query':q['query']} for p in unpack(q['response']))
  ranked=[]
  for p in candidates:
   try:xy=[float(p['XS']),float(p['YS'])]
   except (KeyError,TypeError,ValueError):continue
   if not (120.8<xy[0]<122.25 and 30.6<xy[1]<31.95):continue
   delta=DM[r['district']].distance(Point(*TO_M(*xy)))
   if delta>500:continue
   reason,preferred=acceptable_address(r,p)
   if not reason:continue
   same=name(p.get('NAME',''),r['district'])==name(r['name'],r['district'])
   medical=('卫生' in p.get('NAME','') or '医院' in p.get('NAME',''))
   score=100*preferred+20*same+5*medical+(p['source_kind']=='官方地图检索')
   ranked.append((score,p,reason,xy,delta))
  prop={k:r[k] for k in ['id','district','name','address']}
  prop.update({'source_url':REGISTRY_URL,'registry_date':'2026-03-31','point_source_url':MAP_URL,
      'collected_on':'2026-10-21','included':bool(ranked),'reason':'','point_crs':'EPSG:4326',
      'location_precision':'院址/门牌级，未核实院内入口'})
  geom=None
  if ranked:
   score,p,reason,xy,delta=max(ranked,key=lambda x:x[0])
   prop.update({'match_basis':reason,'map_name':p.get('NAME'),'map_address':p['ADDR'],
      'point_source_kind':p['source_kind'],'map_query':p.get('query'),'distance_from_district_m':round(delta,1)})
   if '公共卫生服务' in r['address'] and p['ADDR']=='凌云路99号':prop['service_address_note']='官网所列公共卫生服务地址；不能据此确认该址全部临床诊疗功能'
   if '分中心' in p.get('NAME',''):prop['legacy_map_classification_note']='地图旧名称含分中心；本次按2026卫健委主中心名录的同一院址匹配，不额外增加机构'
   geom={'type':'Point','coordinates':xy}
  elif r['id'] in supplements:
   extra=supplements[r['id']];xy=extra['coordinates']
   if extra['coordinate_crs']=='GCJ-02':xy=list(gcj_to_wgs(*xy))
   delta=DM[r['district']].distance(Point(*TO_M(*xy)))
   assert delta<500
   prop.update({'included':True,'match_basis':extra['match_basis'],'location_quality':extra['quality'],
      'point_source_url':extra['source_url'],'point_source_kind':'高德补充POI' if extra['coordinate_crs']=='GCJ-02' else 'OSM同名院区面',
      'location_precision':'地图院址POI；未核实院内入口' if extra['coordinate_crs']=='GCJ-02' else '院区包围盒中心；未核实精确门牌或入口',
      'source_coordinate_crs':extra['coordinate_crs'],'source_coordinates':extra['coordinates'],
      'distance_from_district_m':round(delta,1)})
   geom={'type':'Point','coordinates':xy}
  else:prop['reason']='官网当前院址未获得可信坐标；未沿用地址不一致的旧点位'
  features.append({'type':'Feature','properties':prop,'geometry':geom})
 write(HERE/'health_centres.geojson',{'type':'FeatureCollection','registry_source':REGISTRY_URL,
    'registry_date':'2026-03-31','point_source':MAP_URL,'point_crs':'EPSG:4326','features':features})
 audit={'registry_count':len(features),'included_count':sum(f['properties']['included'] for f in features),
    'by_district':[], 'excluded':[f['properties'] for f in features if not f['properties']['included']]}
 for d in DM:
  rr=[f for f in features if f['properties']['district']==d]
  audit['by_district'].append({'name':d,'registry_count':len(rr),'included_count':sum(f['properties']['included'] for f in rr)})
 write(ROOT/'tmp'/'health-audit.json',audit)
 print(json.dumps(audit,ensure_ascii=False,indent=2),flush=True)

def osm_point_sensitivity(fs,main_r85):
 # Supplementary OSM campus centres have lower doorplate certainty.
 good=[f for f in fs if f['properties']['included'] and f['properties']['point_source_kind']!='OSM同名院区面']
 pg=shapely.points([TO_M(*f['geometry']['coordinates']) for f in good]);mask=MASKS['all']
 def cover(r):return shapely.intersection(mask,shapely.union_all(shapely.buffer(pg,r,quad_segs=64))).area/mask.area
 lo,hi=0.,10000.
 while cover(hi)<.85:hi*=2
 while hi-lo>1:
  mid=(hi+lo)/2
  if cover(mid)>=.85:hi=mid
  else:lo=mid
 assert cover(lo)<.85<=cover(hi)
 return {'included_count':len(good),'scope':'all','r85_m':hi,'r85_lower_m':lo,
   'r85_coverage':cover(hi),'coverage_at_main_r85':cover(main_r85)}

def analyze():
 fs=read(HERE/'health_centres.geojson')['features'];results={};scopes={};coverage_features=[];plots=[]
 for scope,mask in MASKS.items():
  selected=[f for f in fs if scope=='all' or f['properties']['district'] in CENTRAL]
  good=[f for f in selected if f['properties']['included']]
  xy=np.array([TO_M(*f['geometry']['coordinates']) for f in good]);tree=cKDTree(xy);pg=shapely.points(xy)
  print('health',scope,'included',len(good),'calculating',flush=True)
  ds25,_=grid_distances(mask,tree,25);ds50,_=grid_distances(mask,tree,50);memo={}
  def service(r):return shapely.union_all(shapely.buffer(pg,r,quad_segs=64))
  def cover(r):
   r=float(r)
   if r not in memo:memo[r]=shapely.intersection(mask,service(r)).area/mask.area
   return memo[r]
  guess=float(np.quantile(ds25,.85));lo=max(0,guess-200);hi=guess+200
  while cover(lo)>.85:lo=max(0,lo-200)
  while cover(hi)<.85:hi+=200
  while hi-lo>1:
   mid=(hi+lo)/2
   if cover(mid)>=.85:hi=mid
   else:lo=mid
  sensitivity=[from_distances(ds25,q) for q in [.90,.95,.99]];knee=sensitivity[1].copy()
  knee['coverage_exact']=cover(knee['radius_m']);knee['gain_next_500m_pp']=100*(cover(knee['radius_m']+500)-knee['coverage_exact'])
  k50=from_distances(ds50,.95);knee['grid50_radius_m']=k50['radius_m']
  thresholds=[0,100,250,300,500,800,1000,1500,2000,3000,5000,10000]
  exact={str(r):cover(r) for r in thresholds}
  sorted_d=np.sort(ds25);maxradius=max(5000,math.ceil(hi/1000)*1000)
  curve=[[r,round(float(np.searchsorted(sorted_d,r,side='right')/len(sorted_d)),7)] for r in range(0,maxradius+26,25)]
  for row in curve:
   if str(row[0]) in exact:row[1]=exact[str(row[0])]
  s={'date':'2026-10-21','scope_id':scope,'scope':'全上海16区' if scope=='all' else '仅中心七区，浦东不纳入',
    'district_names':list(DM) if scope=='all' else CENTRAL,'registry_count':len(selected),'included_count':len(good),
    'excluded_count':len(selected)-len(good),'residential_area_km2':mask.area/1e6,
    'r85_m':hi,'r85_lower_m':lo,'r85_coverage':cover(hi),'coverage_at_lower':cover(lo),
    'r85_25m_grid_m':guess,'r85_50m_grid_m':float(np.quantile(ds50,.85)),
    'knee_m':knee['radius_m'],'knee_coverage':knee['coverage_exact'],'knee':knee,'knee_sensitivity':sensitivity,
    'coverage_at_radii':exact,'curve_25m_grid':curve,'max_radius_m':maxradius,'projection':'EPSG:32651',
    'distance':'straight-line to selected centre site','grid25_area_km2':len(ds25)*625/1e6,'grid50_area_km2':len(ds50)*2500/1e6}
  results[scope]=s
  covered=shapely.intersection(mask,service(hi));uncovered=shapely.difference(mask,service(hi))
  assert cover(lo)<.85<=cover(hi) and abs(guess-hi)<10
  assert abs(knee['coverage_grid']-knee['coverage_exact'])<.005
  assert abs(covered.area+uncovered.area-mask.area)<.1
  for status,g in [('covered',covered),('uncovered',uncovered)]:
   coverage_features.append({'type':'Feature','properties':{'scope':scope,'status':status,'radius_m':hi,
     'area_km2':g.area/1e6,'area_fraction':g.area/mask.area,'source':'© OpenStreetMap contributors, ODbL; Shanghai Health Commission; Shanghai Surveying Institute'},
     'geometry':mapping(transform(TO_LL,g))})
  step=250 if scope=='all' else 100;dv,vxy=grid_distances(mask,tree,step,True)
  lon,lat=TO_LL(vxy[:,0],vxy[:,1]);cells=[[round(float(a),5),round(float(b),5),round(float(c))] for a,b,c in zip(lon,lat,dv)]
  scopes[scope]={'summary':s,'cells':cells,'display_grid_m':step,'points':[{'name':f['properties']['name'],
    'district':f['properties']['district'],'address':f['properties']['address'],'xy':f['geometry']['coordinates']} for f in good]}
  upper=max(10000,math.ceil(float(np.quantile(ds25,.99))/25)*25);xs=np.arange(0,upper+1,25)
  plots.append({'layer':'health','name':'社区卫生服务中心','scope_id':scope,'scope_name':'全上海16区' if scope=='all' else '仅中心七区',
    'main_candidate':knee,'endpoint_sensitivity':sensitivity,'existing_r85_m':hi,
    'curve':[[int(r),float(np.searchsorted(sorted_d,r,side='right')/len(sorted_d))] for r in xs]})
  print(json.dumps({k:s[k] for k in ['scope','registry_count','included_count','r85_m','r85_coverage','knee_m','knee_coverage']},ensure_ascii=False),flush=True)
 write(HERE/'analysis.json',{'results':results,'registry_source_url':REGISTRY_URL,'registry_date':'2026-03-31',
    'point_source_url':MAP_URL,'point_capture_date':'2026-10-21','residential_source':'../社区食堂地图/residential.geojson',
    'exclusions':[f['properties'] for f in fs if not f['properties']['included']],
    'sensitivity_without_3_osm_points':osm_point_sensitivity(fs,results['all']['r85_m'])})
 write(HERE/'coverage_r85.geojson',{'type':'FeatureCollection','features':coverage_features})
 write(ROOT/'tmp'/'health_map_data.json',{'districts':DISTRICTS,'scopes':scopes})
 write(ROOT/'tmp'/'health_tradeoff_plot_data.json',plots)

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--prepare-only',action='store_true');args=ap.parse_args()
 if args.prepare_only:prepare()
 else:analyze()
