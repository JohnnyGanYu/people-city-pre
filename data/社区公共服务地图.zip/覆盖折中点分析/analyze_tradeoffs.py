"""Reproduce coverage-radius trade-off candidates from delivered facility GeoJSON.

No network. Requires the previous two analysis folders and their GIS dependencies.
Candidate selection uses a 25 m residential grid; selected coverage and marginal
gains are checked by original polygon intersections. This is a normalized chord
distance criterion, not the full Kneedle algorithm and not a unique optimum.
"""
import sys, math, json, argparse
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
BASE=HERE.parent/'社区食堂地图'
PUBLIC=HERE.parent/'公共设施覆盖地图'
sys.path.insert(0,str(PUBLIC))
from analyze_coverage import (read,write,shapely,np,shape,transform,TO_M,
    cKDTree,grid_distances,PolygonDistance,MASKS,REGIONS,CENTRAL)
NAMES={'canteen':'社区长者食堂','library':'公共图书馆服务网点',
       'fitness':'公共健身中心','public_green':'公园绿地（待核验初版）'}

def from_distances(ds,q,step=25):
    sd=np.sort(ds);upper=float(np.quantile(sd,q));c0=float(np.searchsorted(sd,0,side='right')/len(sd))
    xs=np.arange(0,upper,step,dtype=float)
    xs=np.append(xs,upper)
    ys=np.searchsorted(sd,xs,side='right')/len(sd)
    ys[-1]=q
    score=(ys-c0)/(q-c0)-xs/upper
    # Earliest radius wins any exact tie.
    i=int(np.argmax(score))
    band=xs[score>=score[i]-.005]
    return {'endpoint_target':q,'endpoint_radius_m_grid':upper,'coverage_at_zero_grid':c0,
        'radius_m':float(xs[i]),'coverage_grid':float(ys[i]),'score':float(score[i]),
        'near_max_score_band_m':[float(band[0]),float(band[-1])],
        'near_max_score_tolerance':.005}

def fixed_upper(ds,upper):
    sd=np.sort(ds);c0=float(np.searchsorted(sd,0,side='right')/len(sd))
    cr=float(np.searchsorted(sd,upper,side='right')/len(sd))
    xs=np.arange(0,upper+1,25);ys=np.searchsorted(sd,xs,side='right')/len(sd)
    score=(ys-c0)/(cr-c0)-xs/upper;i=int(np.argmax(score))
    return {'upper_m':upper,'radius_m':int(xs[i]),'coverage_grid':float(ys[i]),'score':float(score[i])}

def main():
    HERE.mkdir(exist_ok=True);results={};plotdata=[]
    existing=read(PUBLIC/'coverage_results.json')['results']
    existing['canteen']={'all':read(BASE/'analysis.json'),
        'central7':read(BASE/'统计范围'/'central7_analysis.json')}
    for layer,name in NAMES.items():
        source=BASE/'canteens.geojson' if layer=='canteen' else PUBLIC/(layer+'.geojson')
        fs=[f for f in read(source)['features'] if f['properties']['included']]
        isgreen=layer=='public_green';results[layer]={}
        for scope,mask in MASKS.items():
            if isgreen:
                facility=shapely.intersection(shapely.union_all([transform(TO_M,shape(f['geometry'])) for f in fs]),REGIONS[scope])
                tree=PolygonDistance(facility)
            else:
                active=[f for f in fs if scope=='all' or f['properties']['district'] in CENTRAL]
                xy=np.array([TO_M(*f['geometry']['coordinates']) for f in active])
                tree=cKDTree(xy);facility=shapely.points(xy)
            print(layer,scope,'residential grids',flush=True)
            ds25,_=grid_distances(mask,tree,25);ds50,_=grid_distances(mask,tree,50)
            sensitivity=[from_distances(ds25,q) for q in [.90,.95,.99]]
            chosen=sensitivity[1].copy();verify50=from_distances(ds50,.95)
            memo={}
            def cover(r):
                r=float(r)
                if r not in memo:
                    if isgreen:service=shapely.buffer(facility,r,quad_segs=64) if r>0 else facility
                    else:service=shapely.union_all(shapely.buffer(facility,r,quad_segs=64))
                    memo[r]=shapely.intersection(mask,service).area/mask.area
                return memo[r]
            r=chosen['radius_m'];exact=cover(r)
            before=max(0,r-500);after=r+500
            chosen.update({'coverage_exact':exact,'covered_residential_km2':exact*mask.area/1e6,
                'gain_next_500m_pp':100*(cover(after)-exact),
                'gain_previous_window_pp':100*(exact-cover(before)),
                'previous_window_m':r-before,'coverage_at_next_500m':cover(after),
                'coverage_at_previous_window_start':cover(before),
                'grid50_radius_m':verify50['radius_m'],
                'grid50_coverage':verify50['coverage_grid']})
            sd=np.sort(ds25)
            thresholds={str(int(q*100)):float(np.quantile(sd,q)) for q in [.70,.75,.80,.85,.90,.95,.99]}
            result={'name':name,'scope_id':scope,'scope_name':'全上海16区' if scope=='all' else '仅中心七区',
                'residential_km2':mask.area/1e6,'main_candidate':chosen,
                'endpoint_sensitivity':sensitivity,
                'fixed_upper_sensitivity':[fixed_upper(ds25,u) for u in [3000,5000,10000]],
                'target_min_radius_m_grid':thresholds,'existing_r85_m':existing[layer][scope]['r85_m'],
                'existing_r85_coverage_exact':existing[layer][scope]['r85_coverage'],
                'sampling_step_m':25,'source_geojson':str(source.relative_to(ROOT))}
            results[layer][scope]=result
            # No forced exact values inserted in the grid curve; its sampling basis stays consistent.
            xs=np.arange(0,max(10000,math.ceil(thresholds['99']/25)*25)+1,25)
            ys=np.searchsorted(sd,xs,side='right')/len(sd)
            plotdata.append({**result,'layer':layer,'curve':[[int(a),round(float(b),7)] for a,b in zip(xs,ys)]})
            print(json.dumps({'layer':layer,'scope':scope,'candidate_m':r,'coverage_exact':exact,
                'R95_grid':thresholds['95'],'R90_knee':sensitivity[0]['radius_m'],
                'R99_knee':sensitivity[2]['radius_m'],'next500_pp':chosen['gain_next_500m_pp']},ensure_ascii=False),flush=True)
            assert 0<=r<=chosen['endpoint_radius_m_grid']
            assert abs(exact-chosen['coverage_grid'])<.005
            assert chosen['gain_next_500m_pp']>=-1e-8
            assert all(np.diff(ys)>=0)
            assert abs(len(ds25)*625/mask.area-1)<.015
            write(HERE/'tradeoff_results.json',{'analysis_date':'2026-10-14',
                'method':'Maximum positive distance above normalized endpoint chord, sampled every 25 m',
                'main_endpoint_coverage':.95,'sensitivity_endpoint_coverages':[.90,.95,.99],
                'score_formula':'(C(r)-C(0))/(0.95-C(0)) - r/R95_grid',
                'endpoint_is_analyst_choice':True,'not_full_kneedle_algorithm':True,
                'not_a_unique_policy_optimum':True,'results':results})
    write(ROOT/'tmp'/'tradeoff_plot_data.json',plotdata)
    report(results)

def report(results):
    lines=['# 上海公共设施覆盖半径的折中点分析','',
        '分析日期：2026-10-14。沿用2026-10-12采集的设施与绿地快照及既有居住用地范围。',
        '', '## 要回答的问题','',
        '用户确认允许覆盖率低于85%，希望以更短距离获得较大覆盖。本次在固定设施布局下选择服务半径，不涉及重新选址。覆盖率和半径存在取舍，没有无条件唯一的最优数值。',
        '', '覆盖率 C(r) 随服务半径 r 单调不减。直接求 C′(r)=0 常对应饱和平台；经验阶梯曲线还可能在许多小区间导数为0，无法据此选择合理半径。',
        '', '## 本次使用的可复算判据','',
        '保留全部原有居住用地分母，取从0到达到95%覆盖所需半径 R95 的曲线段。95%只定义分析区间上限，不是折中点必须达到的覆盖率；也没有删除最后5%住宅或改变分母。',
        '', '将半径和覆盖增益归一化，计算：',
        '', '`S(r) = [C(r) - C(0)] / [0.95 - C(0)] - r / R95`',
        '', '`r* = argmax S(r), 0 ≤ r ≤ R95`',
        '', '这相当于寻找归一化覆盖曲线高于两端连线的最大距离，是一种简化的弦距膝点判据，并非完整Kneedle算法。若曲线光滑且最优点位于内部，必要条件为 `C′(r*) = [0.95-C(0)]/R95`；在局部凹段还需 `S″(r*)<0`。导数为0的对象是折中得分 S，不是覆盖率 C 本身。',
        '', '候选按25米半径网格搜索；R95取25米住宅网格最近距离分布的95%分位数。候选覆盖率再以原始住宅面与服务缓冲并集求交核验。绿地距范围计算，住宅位于范围内时可有C(0)>0，故扣除基线覆盖。',
        '', '## 主结果：95%上限判据','',
        '| 设施 | 范围 | 候选折中半径 | 核验覆盖率 | 覆盖面积 | 原85%半径 | 再增加500米的增益 |',
        '|---|---|---:|---:|---:|---:|---:|']
    for layer in NAMES:
        for scope,x in results[layer].items():
            c=x['main_candidate']
            lines.append(f"| {x['name']} | {x['scope_name']} | {c['radius_m']/1000:.3f}公里 | {c['coverage_exact']*100:.1f}% | {c['covered_residential_km2']:.2f}平方公里 | {x['existing_r85_m']/1000:.2f}公里 | +{c['gain_next_500m_pp']:.1f}个百分点 |")
    lines+=['','以上候选是有明确分析区间和归一化规则的研究结果，不能称为客观唯一的“最佳服务半径”。膝点覆盖率没有必须达到80%或85%的保证，不能把膝点自动当作“覆盖已经足够”。',
        '', '## 上限与网格敏感性','',
        '| 设施 | 范围 | 90%上限时的候选 | 95%上限时的候选 | 99%上限时的候选 | 50米网格的95%候选 |',
        '|---|---|---:|---:|---:|---:|']
    for layer in NAMES:
        for scope,x in results[layer].items():
            a,b,c=x['endpoint_sensitivity']
            lines.append(f"| {x['name']} | {x['scope_name']} | {a['radius_m']/1000:.3f}公里 / {a['coverage_grid']*100:.1f}% | {b['radius_m']/1000:.3f}公里 / {b['coverage_grid']*100:.1f}% | {c['radius_m']/1000:.3f}公里 / {c['coverage_grid']*100:.1f}% | {x['main_candidate']['grid50_radius_m']/1000:.3f}公里 |")
    lines+=['','若更换上限后候选移动明显，应报告候选区间，或由研究者明确距离成本/最低覆盖要求，而不能只挑一个最有利的数字。完整JSON另列0–3、0–5、0–10公里固定距离上限的结果，便于核查同样的敏感性。',
        '', '每组JSON还给出得分距最大值不超过0.005的候选带（只表示得分接近，不是统计置信区间），以及达到70%、75%、80%、85%、90%、95%、99%覆盖的网格半径。若最后决定至少覆盖80%，可以直接选择满足80%的最短半径；若仍要求85%，既有R85已经是该目标下的最小半径，无需另找导数为0。',
        '', '## 如何用于PPT、GIF和网站','',
        '每类设施增加一张覆盖率—半径曲线，分别标注候选折中点和原85%目标点。GIF先扩大到候选点并停留，再扩大到85%目标点；当某一判据下候选点超过85%目标点时，按半径从小到大展示，不能预设先后。网站可设置“候选折中半径”和“85%目标半径”两种快捷位置，并显示采用的判据。',
        '', '## 数据与适用限制','',
        '全市分母为531.6134平方公里、中心七区约85.7558平方公里的OSM已标注居住用地。七区为黄浦、徐汇、长宁、静安、普陀、虹口、杨浦；浦东仅在全市模式纳入。不是按居民人数加权，未覆盖未标注住宅。',
        '', '食堂采用既有社区长者食堂筛选名录；图书馆为服务网点（不保证自习座位）；健身为平台“市民健身中心”分类；公园绿地为开放状态未逐块核验的OSM初版。全部沿用前两份分析的审计与坐标处理。',
        '', '直线半径未考虑路网、围墙、桥梁、入口、时段、收费和容量，不是步行15分钟覆盖。膝点分析只能优化当前数据和当前距离模型的折中，不能消除源数据误差。',
        '', '## 复现与来源','',
        '`analyze_tradeoffs.py` 默认从前两份分析的已交付GeoJSON复算，无需联网；需保留同级“社区食堂地图”“公共设施覆盖地图”及numpy/scipy/shapely/pyproj依赖。曲线为25米网格估算，候选点覆盖率为原始面核验，两者在图中明确区分。',
        '', '方法背景：[Satopaa等，Finding a Kneedle in a Haystack（2011）](https://www.cs.williams.edu/~jeannie/papers/kneedle-simplex11.pdf)；[Li等，Knee Point Identification Based on Trade-Off Utility（2020）](https://arxiv.org/abs/2005.11600)。本次“95%上限+最大归一化弦距”是为本研究明确选择的简化规则，不将其冒称为文献的完整算法。',
        '', '设施数据来源与排除记录详见 `../社区食堂地图/README.md` 和 `../公共设施覆盖地图/分析说明.md`。居住用地与绿地：© OpenStreetMap contributors，ODbL；[许可说明](https://www.openstreetmap.org/copyright)。','']
    (HERE/'折中点分析说明.md').write_text('\n'.join(lines),'utf-8')

if __name__=='__main__':main()
