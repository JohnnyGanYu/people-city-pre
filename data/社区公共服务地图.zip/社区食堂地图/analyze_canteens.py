"""Reproduce straight-line residential-area coverage from saved public inputs.
Requires numpy, scipy, shapely>=2, pyproj. Inputs are in ../../tmp unless --input is set.
Use --derived to reproduce the main result directly from the delivered GeoJSON files.
The OSM query and source snapshots are documented in README.md.
"""
import argparse, json, math, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
LIB = ROOT / 'tmp' / 'gis-libs'
if LIB.exists(): sys.path.insert(0, str(LIB))
import numpy as np
import shapely
from shapely.geometry import shape, mapping, Polygon, LineString, Point
from shapely.ops import polygonize, transform
from pyproj import Transformer
from scipy.spatial import cKDTree

TO_M = Transformer.from_crs(4326, 32651, always_xy=True).transform
TO_LL = Transformer.from_crs(32651, 4326, always_xy=True).transform

def read(p): return json.loads(Path(p).read_text('utf-8'))
def write(p, value): Path(p).write_text(json.dumps(value, ensure_ascii=False, separators=(',',':')), 'utf-8')

def gcj_to_wgs(lng, lat):
    # Iterative inverse of the standard public GCJ-02 approximation; used only for DataV boundary.
    def forward(lng, lat):
        x,y=lng-105,lat-35
        a=-100+2*x+3*y+.2*y*y+.1*x*y+.2*math.sqrt(abs(x))
        a+=(20*math.sin(6*x*math.pi)+20*math.sin(2*x*math.pi))*2/3
        a+=(20*math.sin(y*math.pi)+40*math.sin(y/3*math.pi))*2/3
        a+=(160*math.sin(y/12*math.pi)+320*math.sin(y*math.pi/30))*2/3
        b=300+x+2*y+.1*x*x+.1*x*y+.1*math.sqrt(abs(x))
        b+=(20*math.sin(6*x*math.pi)+20*math.sin(2*x*math.pi))*2/3
        b+=(20*math.sin(x*math.pi)+40*math.sin(x/3*math.pi))*2/3
        b+=(150*math.sin(x/12*math.pi)+300*math.sin(x/30*math.pi))*2/3
        r=lat*math.pi/180; m=1-.00669342162296594323*math.sin(r)**2
        a=a*180/(6378245*(1-.00669342162296594323)/(m*math.sqrt(m))*math.pi)
        b=b*180/(6378245/math.sqrt(m)*math.cos(r)*math.pi)
        return lng+b,lat+a
    a,b=lng,lat
    for _ in range(5):
        x,y=forward(a,b);a-=x-lng;b-=y-lat
    return a,b

def polygon_parts(g):
    g=shapely.make_valid(g)
    if g.geom_type=='Polygon': return [g]
    if hasattr(g,'geoms'):
        return [p for x in g.geoms for p in polygon_parts(x)]
    return []

def osm_polygons(j):
    out=[]; skipped=[]
    for e in j['elements']:
        if e['type']=='way':
            xy=[(p['lon'],p['lat']) for p in e.get('geometry',[])]
            if len(xy)>=4 and xy[0]==xy[-1]: out.extend(polygon_parts(Polygon(xy)))
            else: skipped.append(['way',e['id'],'not closed'])
        elif e['type']=='relation':
            outer=[];inner=[]
            for m in e.get('members',[]):
                xy=[(p['lon'],p['lat']) for p in m.get('geometry',[]) if p and 'lon' in p]
                if len(xy)>=2: (inner if m.get('role')=='inner' else outer).append(LineString(xy))
            a=shapely.union_all(list(polygonize(outer)))
            b=shapely.union_all(list(polygonize(inner))) if inner else None
            if b is not None: a=shapely.difference(a,b)
            parts=polygon_parts(a)
            if parts: out.extend(parts)
            else: skipped.append(['relation',e['id'],'no polygon'])
    return out,skipped

def grid_distances(mask, tree, step, save_xy=False):
    xmin,ymin,xmax,ymax=mask.bounds
    xs=np.arange(math.floor(xmin/step)*step+step/2,xmax,step)
    ys=np.arange(math.floor(ymin/step)*step+step/2,ymax,step)
    shapely.prepare(mask)
    ds=[];xy_all=[]
    for start in range(0,len(ys),60):
        xx,yy=np.meshgrid(xs,ys[start:start+60]);xx=xx.ravel();yy=yy.ravel()
        keep=shapely.contains_xy(mask,xx,yy)
        xy=np.column_stack([xx[keep],yy[keep]])
        if len(xy):
            ds.append(tree.query(xy,workers=-1)[0])
            if save_xy: xy_all.append(xy)
    dist=np.concatenate(ds)
    return dist, np.concatenate(xy_all) if save_xy else None

def run(inp, out):
    out.mkdir(parents=True,exist_ok=True)
    registry=read(inp/'shyl-canteens-new.json')['data']['records']
    map_points=read(inp/'mfw-canteens-wgs84.json')['data']
    lookup={p['organizationCode']:p for p in map_points}
    for key in ['js','cm','jd']:
        p=inp/f'mfw-missing-{key}-result.json'
        if p.exists(): lookup.update({x['organizationCode']:x for x in read(p)['data']})
    districts=[]
    for f in read(inp/'shanghai-districts-gcj02.json')['features']:
        g=transform(gcj_to_wgs,shape(f['geometry']))
        districts.append({'type':'Feature','properties':{'name':f['properties']['name'],'adcode':f['properties']['adcode']},'geometry':mapping(g)})
    dm={int(f['properties']['adcode']):transform(TO_M,shape(f['geometry'])) for f in districts}
    city=shapely.union_all(list(dm.values()))
    features=[];excluded=[]
    for r in registry:
        p=lookup.get(r['organId']);reason='';coord=None;outside=None
        if not p: reason='官方地图未匹配到编号'
        else:
            coord=[p['wgsLongitude'],p['wgsLatitude']]
            if p['organizationType']!=4: reason='名录为长者食堂、地图分类为助餐点，待核实'
            elif not (120.8<coord[0]<122.25 and 30.6<coord[1]<31.95): reason='坐标不在合理范围'
            else:
                pt=Point(*TO_M(*coord));district=dm.get(int(r['regionCode'][:6]))
                outside=district.distance(pt)
                if outside>500: reason=f'坐标偏离所属区{outside/1000:.1f}公里，待核实'
        prop={'id':r['organId'],'name':r['orgName'],'district':r['regionName'],'address':r['orgAddress'],'included':not bool(reason),'reason':reason,'map_type':p.get('organizationTypeName') if p else None,'crs':'WGS84'}
        features.append({'type':'Feature','properties':prop,'geometry':{'type':'Point','coordinates':coord} if coord else None})
        if reason:excluded.append(prop)
    good=[f for f in features if f['properties']['included']]
    xy=np.array([TO_M(*f['geometry']['coordinates']) for f in good]);tree=cKDTree(xy)
    write(out/'canteens.geojson',{'type':'FeatureCollection','features':features})
    write(out/'districts.geojson',{'type':'FeatureCollection','features':districts})
    write(out/'point_audit.json',{'date':'2026-10-12','registry_count':len(registry),'map_category_query_count':len(map_points),'included_count':len(good),'excluded':excluded})
    osm=read(inp/'osm-residential.json')
    polys,skipped=osm_polygons(osm)
    print('parsed residential polygons',len(polys),'skipped',len(skipped),flush=True)
    geoms=[transform(TO_M,p) for p in polys]
    mask=shapely.intersection(shapely.union_all(geoms),city)
    mask=shapely.union_all(polygon_parts(mask))
    mask_ll=transform(TO_LL,mask)
    write(out/'residential.geojson',{'type':'FeatureCollection','features':[{'type':'Feature','properties':{'source':'OpenStreetMap landuse=residential','timestamp':osm['osm3s']['timestamp_osm_base'],'area_km2':mask.area/1e6},'geometry':mapping(mask_ll)}]})
    print('residential area km2',mask.area/1e6,'valid points',len(good),flush=True)
    ds50,_=grid_distances(mask,tree,50)
    ds25,_=grid_distances(mask,tree,25)
    print('grid R85 50m/25m',np.quantile(ds50,.85),np.quantile(ds25,.85),flush=True)
    point_geom=shapely.points(xy)
    memo={}
    def cover(r):
        r=float(r)
        if r not in memo:
            disks=shapely.union_all(shapely.buffer(point_geom,r,quad_segs=64))
            memo[r]=shapely.intersection(mask,disks).area/mask.area
        return memo[r]
    guess=float(np.quantile(ds25,.85));lo=max(0,guess-150);hi=guess+150
    while cover(lo)>.85:lo=max(0,lo-150)
    while cover(hi)<.85:hi+=150
    while hi-lo>1:
        mid=(hi+lo)/2
        if cover(mid)>=.85:hi=mid
        else:lo=mid
    r85=hi
    print('polygon R85',r85,'coverage',cover(r85),flush=True)
    export_coverage(out,mask,point_geom,r85)
    thresholds=[300,500,800,1000,1500,2000,3000,5000]
    exact={str(r):cover(r) for r in thresholds}
    sorted_d=np.sort(ds25)
    curve=[[r,round(float(np.searchsorted(sorted_d,r,side='right')/len(sorted_d)),6)] for r in range(0,max(10000,int(sorted_d[-1])+100),25)]
    for row in curve:
        if str(row[0]) in exact:row[1]=exact[str(row[0])]
    dv,vxy=grid_distances(mask,tree,250,True)
    vlng,vlat=TO_LL(vxy[:,0],vxy[:,1])
    cells=[[round(float(a),5),round(float(b),5),round(float(c))] for a,b,c in zip(vlng,vlat,dv)]
    summary={'date':'2026-10-12','scope':'上海边界内OSM已标注的landuse=residential居住用地','osm_timestamp':osm['osm3s']['timestamp_osm_base'],'registry_count':len(registry),'included_count':len(good),'excluded_count':len(excluded),'residential_area_km2':mask.area/1e6,'projection':'EPSG:32651','distance':'straight-line','target_area_fraction':.85,'r85_m':r85,'r85_coverage':cover(r85),'r85_50m_grid_m':float(np.quantile(ds50,.85)),'r85_25m_grid_m':guess,'grid50_area_km2':len(ds50)*2500/1e6,'grid25_area_km2':len(ds25)*625/1e6,'source_element_count':len(osm['elements']),'parsed_polygon_count':len(polys),'skipped_osm_elements':skipped,'coverage_at_radii':exact,'buffer_quad_segs':64,'binary_search_tolerance_m':1,'curve_25m_grid':curve,'districts':[]}
    for code,dg in dm.items():
        g=shapely.intersection(mask,dg);dd=shapely.intersection(g,shapely.union_all(shapely.buffer(point_geom,r85,quad_segs=64)))
        n=next(f['properties']['name'] for f in districts if f['properties']['adcode']==code)
        summary['districts'].append({'name':n,'residential_km2':g.area/1e6,'coverage_at_citywide_r85':dd.area/g.area if g.area else None,'canteens':sum(f['properties']['district']==n for f in good)})
    write(out/'analysis.json',summary)
    # Inline map uses a coarser grid only for display; the analytical result uses polygon intersections.
    light=transform(TO_LL,mask.simplify(90,preserve_topology=True))
    compact=lambda g:json.loads(shapely.to_geojson(shapely.set_precision(g,0.00001)))
    data={'summary':summary,'districts':{'type':'FeatureCollection','features':districts},'residential':compact(light),'cells':cells,'points':[{'name':f['properties']['name'],'district':f['properties']['district'],'address':f['properties']['address'],'xy':f['geometry']['coordinates']} for f in good]}
    write(out/'map_data.json',data)
    print('COMPLETE',json.dumps({k:summary[k] for k in ['r85_m','residential_area_km2','included_count','r85_coverage']},ensure_ascii=True),flush=True)

def export_coverage(folder,mask,pg,r85):
    disks=shapely.union_all(shapely.buffer(pg,r85,quad_segs=64))
    inside=shapely.intersection(mask,disks)
    outside=shapely.difference(mask,disks)
    features=[]
    for status,g in [('covered',inside),('uncovered',outside)]:
        features.append({'type':'Feature','properties':{'status':status,'radius_m':r85,'area_km2':g.area/1e6,
            'area_fraction':g.area/mask.area,'source':'OpenStreetMap contributors, ODbL; Shanghai civil affairs canteens'},
            'geometry':mapping(transform(TO_LL,g))})
    write(folder/'coverage_r85.geojson',{'type':'FeatureCollection','features':features})

def reproduce_derived(folder):
    mask=transform(TO_M,shape(read(folder/'residential.geojson')['features'][0]['geometry']))
    points=read(folder/'canteens.geojson')['features']
    xy=[TO_M(*f['geometry']['coordinates']) for f in points if f['properties']['included']]
    pg=shapely.points(xy)
    if (folder/'analysis.json').exists():
        export_coverage(folder,mask,pg,read(folder/'analysis.json')['r85_m'])
    def coverage(r):
        disks=shapely.union_all(shapely.buffer(pg,r,quad_segs=64))
        return shapely.intersection(mask,disks).area/mask.area
    lo,hi=0.,10000.
    while hi-lo>1:
        mid=(lo+hi)/2
        if coverage(mid)>=.85:hi=mid
        else:lo=mid
    print(json.dumps({'included_count':len(xy),'residential_area_km2':mask.area/1e6,
        'r85_lower_m':lo,'r85_upper_m':hi,'coverage_at_lower':coverage(lo),'coverage_at_upper':coverage(hi)},ensure_ascii=True))

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--input',type=Path,default=ROOT/'tmp')
    ap.add_argument('--output',type=Path,default=HERE)
    ap.add_argument('--derived',action='store_true',help='Reproduce R85 from delivered GeoJSON; no source cache needed.')
    args=ap.parse_args()
    if args.derived:reproduce_derived(args.output)
    else:run(args.input,args.output)
