"""Create two scope definitions from the delivered Shanghai canteen GeoJSON.
Run from any directory. Requires analyze_canteens.py and its GIS dependencies.
No network access is used. Detailed input provenance is in README.md.
"""
from pathlib import Path
import numpy as np
from analyze_canteens import (read, write, transform, shape, mapping, shapely,
    TO_M, TO_LL, cKDTree, grid_distances)

HERE=Path(__file__).resolve().parent
OUT=HERE/'统计范围'
CENTRAL=['黄浦区','徐汇区','长宁区','静安区','普陀区','虹口区','杨浦区']

def main():
    OUT.mkdir(exist_ok=True)
    base=read(HERE/'analysis.json')
    districts=read(HERE/'districts.geojson')
    central_districts={'type':'FeatureCollection','features':[f for f in districts['features'] if f['properties']['name'] in CENTRAL]}
    region=shapely.union_all([transform(TO_M,shape(f['geometry'])) for f in central_districts['features']])
    fullmask=transform(TO_M,shape(read(HERE/'residential.geojson')['features'][0]['geometry']))
    mask=shapely.intersection(fullmask,region)
    all_features=read(HERE/'canteens.geojson')['features']
    features=[f for f in all_features if f['properties']['district'] in CENTRAL]
    good=[f for f in features if f['properties']['included']]
    points=[{'id':f['properties']['id'],'name':f['properties']['name'],'district':f['properties']['district'],
        'address':f['properties']['address'],'xy':f['geometry']['coordinates']} for f in good]
    xy=np.array([TO_M(*p['xy']) for p in points]);tree=cKDTree(xy);pg=shapely.points(xy)
    ds50,_=grid_distances(mask,tree,50)
    ds25,_=grid_distances(mask,tree,25)
    memo={}
    def cover(r):
        r=float(r)
        if r not in memo:
            disks=shapely.union_all(shapely.buffer(pg,r,quad_segs=64))
            memo[r]=shapely.intersection(mask,disks).area/mask.area
        return memo[r]
    lo,hi=0.,5000.
    while hi-lo>1:
        mid=(lo+hi)/2
        if cover(mid)>=.85:hi=mid
        else:lo=mid
    r85=hi
    exact={str(r):cover(r) for r in [250,300,500,800,1000,1500,2000,3000,5000]}
    sd=np.sort(ds25)
    curve=[[r,float(np.searchsorted(sd,r,side='right')/len(sd))] for r in range(0,5001,25)]
    for row in curve:
        if str(row[0]) in exact:row[1]=exact[str(row[0])]
    summary={'date':base['date'],'scope_id':'central7','scope':'不包括郊区：仅中心城区七区的OSM已标注居住用地',
        'district_names':CENTRAL,'pudong_policy':'浦东单列，本范围不纳入；未把浦东整体归为郊区',
        'boundary_rule':'食堂按名录所属区筛选；住宅用地按七区面裁切；仅使用所选范围内食堂',
        'classification_source':'https://tjj.sh.gov.cn/tjnj/2020rktjnj/fu02.pdf',
        'registry_count':len(features),'included_count':len(good),'excluded_count':len(features)-len(good),
        'residential_area_km2':mask.area/1e6,'projection':'EPSG:32651','distance':'straight-line',
        'target_area_fraction':.85,'r85_m':r85,'r85_lower_m':lo,'r85_coverage':cover(r85),'coverage_at_lower':cover(lo),
        'r85_50m_grid_m':float(np.quantile(ds50,.85)),'r85_25m_grid_m':float(np.quantile(ds25,.85)),
        'grid50_area_km2':len(ds50)*2500/1e6,'grid25_area_km2':len(ds25)*625/1e6,
        'coverage_at_radii':exact,'curve_25m_grid':curve,'binary_search_tolerance_m':1,'buffer_quad_segs':64,
        'osm_timestamp':base['osm_timestamp']}
    write(OUT/'central7_analysis.json',summary)
    write(OUT/'central7_canteens.geojson',{'type':'FeatureCollection','features':features})
    write(OUT/'central7_residential.geojson',{'type':'FeatureCollection','features':[{'type':'Feature',
        'properties':{'source':'OpenStreetMap contributors, ODbL','scope':'central7','area_km2':mask.area/1e6,
            'timestamp':base['osm_timestamp']},'geometry':mapping(transform(TO_LL,mask))}]})
    disks=shapely.union_all(shapely.buffer(pg,r85,quad_segs=64))
    cf=[]
    for status,g in [('covered',shapely.intersection(mask,disks)),('uncovered',shapely.difference(mask,disks))]:
        cf.append({'type':'Feature','properties':{'scope':'central7','status':status,'radius_m':r85,
            'area_fraction':g.area/mask.area,'area_km2':g.area/1e6,
            'source':'OpenStreetMap contributors, ODbL; Shanghai civil affairs canteens'},
            'geometry':mapping(transform(TO_LL,g))})
    write(OUT/'central7_coverage_r85.geojson',{'type':'FeatureCollection','features':cf})
    ds,coords=grid_distances(mask,tree,100,True)
    lon,lat=TO_LL(coords[:,0],coords[:,1])
    cells=[[round(float(a),5),round(float(b),5),round(float(c))] for a,b,c in zip(lon,lat,ds)]
    write(HERE.parents[1]/'tmp'/'central7_map_data.json',{'summary':summary,'districts':central_districts,'points':points,'cells':cells,'display_grid_m':100})
    brief=lambda s:{k:s[k] for k in ['scope','registry_count','included_count','residential_area_km2','r85_m','r85_coverage']}
    write(OUT/'scope_summary.json',{'all_shanghai':brief(base),'central7':brief(summary),'pudong_policy':summary['pudong_policy'],
        'boundary_rule':summary['boundary_rule'],'classification_source':summary['classification_source']})
    print(__import__('json').dumps({k:summary[k] for k in ['included_count','residential_area_km2','r85_m','r85_coverage','coverage_at_lower','r85_25m_grid_m','r85_50m_grid_m']},ensure_ascii=True))

if __name__=='__main__':main()
