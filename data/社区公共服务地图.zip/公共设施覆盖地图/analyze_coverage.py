"""Shanghai library / public fitness centre / public park coverage.

Run with --prepare to rebuild audited input GeoJSON from cached public snapshots.
Run without arguments to reproduce six area-weighted R85 results from GeoJSON.
Requires numpy, scipy, shapely>=2, pyproj; reuses the canteen analysis helpers
and its residential mask/district boundaries in ../社区食堂地图.
"""
import sys, math, argparse, json, collections
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8')
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
BASE=HERE.parent/'社区食堂地图'
sys.path.insert(0,str(BASE))
from analyze_canteens import (read,write,gcj_to_wgs,osm_polygons,polygon_parts,
    shapely,np,shape,mapping,Point,transform,TO_M,TO_LL,cKDTree,grid_distances)
CENTRAL=['黄浦区','徐汇区','长宁区','静安区','普陀区','虹口区','杨浦区']
DISTRICTS=read(BASE/'districts.geojson')
DM={f['properties']['name']:transform(TO_M,shape(f['geometry'])) for f in DISTRICTS['features']}
CITY=shapely.union_all(list(DM.values()))
CENTRAL_REGION=shapely.union_all([DM[n] for n in CENTRAL])
MASK=transform(TO_M,shape(read(BASE/'residential.geojson')['features'][0]['geometry']))
MASKS={'all':MASK,'central7':shapely.intersection(MASK,CENTRAL_REGION)}
REGIONS={'all':CITY,'central7':CENTRAL_REGION}
LIB_CLOSED={'J164-Z1','G09-Z3','J130-Z1','J067','J161-F1','J044','J084',
    'G28','J172','J124-Z3','J190','J191','J222'}
SOURCE_URLS={
 'library':'https://www.library.sh.cn/guide/libraryLocation',
 'fitness':'https://www.shggty.com.cn/facilityMap.html',
 'green':'https://www.openstreetmap.org/copyright'}

def point_audit(p,coord,official_district=None):
    """Do not move points or silently repair coordinate/address disagreement."""
    if not coord or not all(math.isfinite(x) for x in coord):
        p['reasons'].append('缺失有效坐标');return None
    if not (120.8<coord[0]<122.25 and 30.6<coord[1]<31.95):
        p['reasons'].append('坐标超出合理范围');return None
    ll=gcj_to_wgs(*coord);pt=Point(*TO_M(*ll))
    nearest=min(DM,key=lambda n:DM[n].distance(pt))
    p['spatial_district']=nearest
    if official_district in DM:
        p['district']=official_district
        d=DM[official_district].distance(pt)
        p['distance_from_official_district_m']=round(d,1)
        if d>500:p['reasons'].append('坐标偏离所属区超过500米，待核实')
    else:p['district']=nearest
    if CITY.distance(pt)>500:p['reasons'].append('坐标偏离上海边界超过500米')
    return {'type':'Point','coordinates':[round(x,7) for x in ll]}

def prepare():
    cached=ROOT/'tmp';lib=[];fit=[];green=[];green_excluded=[]
    for x in read(cached/'library-points.json')['data']['result']:
        p={'id':x['gcode'],'name':x['libname'],'district':x.get('district'),
           'address':x.get('address'),'level':x.get('level'),'opening_note':x.get('opentime'),
           'source_status':x.get('status'),'reasons':[],'source_url':SOURCE_URLS['library']}
        if x['gcode'] in LIB_CLOSED:p['reasons'].append('官网备注暂停服务或闭馆改造，未见恢复公告')
        if x['gcode']=='J063':p['reasons'].append('官网已迁安业路76号，但地址/坐标仍指保德路181号，待核实')
        try:coord=[float(x['tencentx']),float(x['tencenty'])]
        except (ValueError,KeyError,TypeError):coord=None
        g=point_audit(p,coord,x.get('district'))
        p['included']=not p['reasons'];lib.append({'type':'Feature','properties':p,'geometry':g})
    for f in sorted((cached/'sports-centres-details').glob('*.json')):
        x=read(f)['data']
        p={'id':x['id'],'name':x['name'],'district':x.get('districtName'),'address':x.get('address'),
           'type':x.get('typeName'),'suspended':x.get('suspended'),
           'workday_open':x.get('workdayOpenTime'),'workday_close':x.get('workdayCloseTime'),
           'weekend_open':x.get('weekdayOpenTime'),'weekend_close':x.get('weekdayCloseTime'),
           'reasons':[],'source_url':SOURCE_URLS['fitness']}
        if x.get('suspended'):p['reasons'].append('平台详情标记 suspended=true')
        try:coord=[float(x['longitude']),float(x['latitude'])]
        except (ValueError,KeyError,TypeError):coord=None
        g=point_audit(p,coord,x.get('districtName'))
        p['included']=not p['reasons'];fit.append({'type':'Feature','properties':p,'geometry':g})
    # Exact same normalized name + address + very close position indicates a duplicate record.
    for fs in [lib,fit]:
        prior={}
        for f in fs:
            p=f['properties'];key=(p['name'].replace(' ',''),str(p['address']).replace(' ',''))
            if p['included'] and key in prior:
                prev=prior[key]
                if Point(*TO_M(*f['geometry']['coordinates'])).distance(Point(*TO_M(*prev['geometry']['coordinates'])))<100:
                    p['reasons'].append('与同名同址记录重复');p['included']=False
            if p['included']:prior[key]=f
    osm=read(cached/'osm-green-spaces.json')
    for e in osm['elements']:
        t=e.get('tags',{});acc=t.get('foot',t.get('access','unknown'))
        if acc in ['no','private','customers','permit','military']:continue
        if t.get('disused')=='yes' or t.get('abandoned')=='yes' or t.get('construction')=='yes':continue
        kind=t.get('leisure');namedpark=any(w in t.get('name','') for w in ['公园','公園'])
        explicit=acc in ['yes','public','permissive','designated']
        selected=kind=='park' or (kind=='garden' and (explicit or t.get('garden:type') in ['public','municipal']))
        selected=selected or (namedpark and t.get('landuse') in ['forest','recreation_ground','village_green'])
        if not selected:continue
        if t.get('garden:type') in ['private','residential','school'] and not explicit:continue
        ps,skipped=osm_polygons({'elements':[e]})
        if not ps:green_excluded.append({'id':str(e['type'])+'/'+str(e['id']),'reason':skipped});continue
        g=shapely.intersection(shapely.union_all([transform(TO_M,p) for p in ps]),CITY)
        g=shapely.union_all(polygon_parts(g))
        if g.is_empty:continue
        p={'id':str(e['type'])+'/'+str(e['id']),'name':t.get('name','未标注名称'),
           'leisure':kind,'landuse':t.get('landuse'),'access':t.get('access','unknown'),
           'foot':t.get('foot'),'garden_type':t.get('garden:type'),
           'public_access_basis':'明确开放标签' if explicit else '按公园类标签推定，开放状态未核实',
           'included':True,'area_m2':g.area,'source_url':'https://www.openstreetmap.org/'+e['type']+'/'+str(e['id'])}
        green.append({'type':'Feature','properties':p,'geometry':mapping(transform(TO_LL,g))})
    for name,fs in [('library',lib),('fitness',fit),('public_green',green)]:
        write(HERE/(name+'.geojson'),{'type':'FeatureCollection','source_url':SOURCE_URLS.get(name,SOURCE_URLS['green']),
            'collected_on':'2026-10-12','crs_note':'WGS84; library/fitness converted from public-map GCJ-02 with iterative approximation',
            'license_note':'Green data: © OpenStreetMap contributors, ODbL', 'features':fs})
    audit={'library':{'source_records':len(lib),'included':sum(x['properties']['included'] for x in lib),
                     'excluded':[x['properties'] for x in lib if not x['properties']['included']]},
        'fitness':{'source_records':len(fit),'map_list_records':len(read(cached/'sports-centres-map.json')['data']),
                   'included':sum(x['properties']['included'] for x in fit),
                   'excluded':[x['properties'] for x in fit if not x['properties']['included']]},
        'green':{'source_elements':len(osm['elements']),'selected_surface_features':len(green),'skipped_geometry':green_excluded,
                 'osm_timestamp':osm['osm3s']['timestamp_osm_base'],
                 'access_basis':dict(collections.Counter(f['properties']['public_access_basis'] for f in green))}}
    write(ROOT/'tmp'/'facility_audit.json',audit)
    print(json.dumps(audit,ensure_ascii=False,indent=2),flush=True)

class PolygonDistance:
    def __init__(self,g):self.tree=shapely.STRtree(polygon_parts(g))
    def query(self,xy,workers=-1):
        indices,ds=self.tree.query_nearest(shapely.points(xy),return_distance=True,all_matches=False)
        out=np.empty(len(xy));out[indices[0]]=ds
        return out,None

def analyze():
    (ROOT/'tmp').mkdir(exist_ok=True)
    prior=read(HERE/'coverage_results.json').get('audit') if (HERE/'coverage_results.json').exists() else None
    audit=read(ROOT/'tmp'/'facility_audit.json') if (ROOT/'tmp'/'facility_audit.json').exists() else prior
    summaries={};allcoverage=[]
    for layer in ['library','fitness','public_green']:
        fs=[f for f in read(HERE/(layer+'.geojson'))['features'] if f['properties']['included']]
        isgreen=layer=='public_green';summaries[layer]={};mapscopes={}
        for scope,mask in MASKS.items():
            if isgreen:
                active=[f for f in fs if shape(f['geometry']).intersects(transform(TO_LL,REGIONS[scope]))]
                facility=shapely.intersection(shapely.union_all([transform(TO_M,shape(f['geometry'])) for f in active]),REGIONS[scope])
                tree=PolygonDistance(facility)
            else:
                active=[f for f in fs if scope=='all' or f['properties']['district'] in CENTRAL]
                xy=np.array([TO_M(*f['geometry']['coordinates']) for f in active]);facility=shapely.points(xy);tree=cKDTree(xy)
            print(layer,scope,'sources',len(active),'calculating grids',flush=True)
            ds50,_=grid_distances(mask,tree,50);ds25,_=grid_distances(mask,tree,25)
            memo={}
            def buffer(r):
                if isgreen:return shapely.buffer(facility,r,quad_segs=64) if r>0 else facility
                return shapely.union_all(shapely.buffer(facility,r,quad_segs=64))
            def coverage(r):
                r=float(r)
                if r not in memo:memo[r]=shapely.intersection(mask,buffer(r)).area/mask.area
                return memo[r]
            guess=float(np.quantile(ds25,.85));lo=max(0,guess-200);hi=guess+200
            while coverage(lo)>.85 and lo>0:lo=max(0,lo-200)
            while coverage(hi)<.85:hi+=200
            while hi-lo>1:
                mid=(hi+lo)/2
                if coverage(mid)>=.85:hi=mid
                else:lo=mid
            r85=hi
            thresholds=[0,100,250,300,500,800,1000,1500,2000,3000,5000,10000]
            exact={str(r):coverage(r) for r in thresholds}
            sd=np.sort(ds25);maxradius=max(5000,math.ceil(r85/1000)*1000)
            curve=[[r,round(float(np.searchsorted(sd,r,side='right')/len(sd)),6)] for r in range(0,maxradius+26,25)]
            for row in curve:
                if str(row[0]) in exact:row[1]=exact[str(row[0])]
            s={'layer':layer,'scope_id':scope,'scope':'全上海16区' if scope=='all' else '仅中心七区，浦东不纳入',
               'district_names':list(DM) if scope=='all' else CENTRAL,'date':'2026-10-12','included_count':len(active),
               'residential_area_km2':mask.area/1e6,'r85_lower_m':lo,'r85_m':r85,'r85_coverage':coverage(r85),
               'coverage_at_lower':coverage(lo),'r85_25m_grid_m':guess,'r85_50m_grid_m':float(np.quantile(ds50,.85)),
               'grid25_area_km2':len(ds25)*625/1e6,'grid50_area_km2':len(ds50)*2500/1e6,
               'coverage_at_radii':exact,'curve_25m_grid':curve,'max_radius_m':maxradius,
               'projection':'EPSG:32651','distance':'straight-line to polygon range' if isgreen else 'straight-line to point',
               'target_area_fraction':.85,'buffer_quad_segs':64,'binary_search_tolerance_m':1,
               'facility_union_area_km2':facility.area/1e6 if isgreen else None}
            summaries[layer][scope]=s
            covered=shapely.intersection(mask,buffer(r85));uncovered=shapely.difference(mask,buffer(r85))
            for status,g in [('covered',covered),('uncovered',uncovered)]:
                allcoverage.append({'type':'Feature','properties':{'layer':layer,'scope':scope,'status':status,
                    'radius_m':r85,'area_km2':g.area/1e6,'area_fraction':g.area/mask.area,
                    'source':'© OpenStreetMap contributors, ODbL; '+SOURCE_URLS.get(layer,SOURCE_URLS['green'])},
                    'geometry':mapping(transform(TO_LL,g))})
            step=250 if scope=='all' else 100;dv,vxy=grid_distances(mask,tree,step,True)
            lng,lat=TO_LL(vxy[:,0],vxy[:,1]);cells=[[round(float(a),5),round(float(b),5),round(float(c))] for a,b,c in zip(lng,lat,dv)]
            display={'summary':s,'cells':cells,'display_grid_m':step,'points':[]}
            if isgreen:
                light=transform(TO_LL,facility.simplify(35,preserve_topology=True))
                display['green']=json.loads(shapely.to_geojson(shapely.set_precision(light,0.00001)))
            else:display['points']=[{'name':f['properties']['name'],'address':f['properties']['address'],
                'district':f['properties']['district'],'xy':f['geometry']['coordinates']} for f in active]
            mapscopes[scope]=display
            print(json.dumps({k:s[k] for k in ['layer','scope_id','included_count','r85_m','r85_coverage','r85_25m_grid_m']},ensure_ascii=False),flush=True)
        write(ROOT/'tmp'/(layer+'_map_data.json'),{'districts':DISTRICTS,'scopes':mapscopes})
        write(HERE/'coverage_results.json',{'results':summaries,'audit':audit,
            'denominator_source':'../社区食堂地图/residential.geojson','central_definition':CENTRAL,
            'scope_rule':'仅使用所选范围内设施；图书馆及健身中心按官网所属区，绿地按范围裁切；允许范围内部跨区服务',
            'residential_osm_timestamp':read(BASE/'analysis.json')['osm_timestamp']})
    write(HERE/'coverage_r85.geojson',{'type':'FeatureCollection','features':allcoverage})

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--prepare',action='store_true');ap.add_argument('--prepare-only',action='store_true');args=ap.parse_args()
    if args.prepare or args.prepare_only:prepare()
    if not args.prepare_only:analyze()
