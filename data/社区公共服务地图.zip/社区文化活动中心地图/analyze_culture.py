"""Reproduce community cultural-centre coverage from audited GeoJSON, offline.
Requires the existing residential mask and GIS/tradeoff helpers in this project.
The official 221 groups expand into 286 source site rows; not every row is open
or located. Coverage uses included physical sites, not institution counts.
"""
import sys,math,json
from pathlib import Path
sys.stdout.reconfigure(encoding='utf-8');HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path.insert(0,str(HERE.parent/'公共设施覆盖地图'))
from analyze_coverage import (read,write,DM,DISTRICTS,CENTRAL,REGIONS,MASKS,shapely,np,
 shape,mapping,Point,transform,TO_M,TO_LL,cKDTree,grid_distances)
sys.path.insert(0,str(HERE.parent/'覆盖折中点分析'))
from analyze_tradeoffs import from_distances
REGISTRY_URL='https://whlyj.sh.gov.cn/sqwhhdzx/20260818/c50581fd2b7541fb81824a485f3a368b.html'
def analyze():
 fs=read(HERE/'culture_centres.geojson')['features'];results={};scopes={};polygons=[];plots=[]
 for scope,mask in MASKS.items():
  selected=[f for f in fs if scope=='all' or f['properties']['district'] in CENTRAL]
  good=[f for f in selected if f['properties']['included']]
  xy=np.array([TO_M(*f['geometry']['coordinates']) for f in good]);tree=cKDTree(xy);pg=shapely.points(xy)
  print(scope,'sites',len(good),flush=True)
  ds25,_=grid_distances(mask,tree,25);ds50,_=grid_distances(mask,tree,50);memo={}
  def service(r):return shapely.union_all(shapely.buffer(pg,r,quad_segs=64))
  def cover(r):
   r=float(r)
   if r not in memo:memo[r]=shapely.intersection(mask,service(r)).area/mask.area
   return memo[r]
  guess=float(np.quantile(ds25,.85));lo=max(0,guess-200);hi=guess+200
  while cover(lo)>.85:lo=max(0,lo-200)
  while cover(hi)<.85:hi+=200
  while hi-lo>1:
   mid=(hi+lo)/2
   if cover(mid)>=.85:hi=mid
   else:lo=mid
  sensitivity=[from_distances(ds25,q) for q in [.90,.95,.99]];knee=sensitivity[1].copy()
  knee['coverage_exact']=cover(knee['radius_m']);knee['gain_next_500m_pp']=100*(cover(knee['radius_m']+500)-knee['coverage_exact'])
  knee['grid50_radius_m']=from_distances(ds50,.95)['radius_m']
  exact={str(r):cover(r) for r in [0,100,250,300,500,800,1000,1500,2000,3000,5000,10000]}
  sorted_d=np.sort(ds25);maximum=max(5000,math.ceil(hi/1000)*1000)
  curve=[[r,exact.get(str(r),round(float(np.searchsorted(sorted_d,r,side='right')/len(sorted_d)),7))] for r in range(0,maximum+26,25)]
  s={'date':'2026-10-21','scope_id':scope,'scope':'全上海16区' if scope=='all' else '仅中心七区，浦东不纳入',
   'district_names':list(DM) if scope=='all' else CENTRAL,'registry_count':len(selected),'included_count':len(good),'excluded_count':len(selected)-len(good),
   'registry_groups':len({f['properties']['group_id'] for f in selected}),'located_groups':len({f['properties']['group_id'] for f in good}),
   'residential_area_km2':mask.area/1e6,'r85_m':hi,'r85_lower_m':lo,'r85_coverage':cover(hi),'coverage_at_lower':cover(lo),
   'r85_25m_grid_m':guess,'r85_50m_grid_m':float(np.quantile(ds50,.85)),
   'knee_m':knee['radius_m'],'knee_coverage':knee['coverage_exact'],'knee':knee,'knee_sensitivity':sensitivity,
   'coverage_at_radii':exact,'curve_25m_grid':curve,'max_radius_m':maximum,'projection':'EPSG:32651',
   'distance':'straight-line to included cultural-centre sites','grid25_area_km2':len(ds25)*625/1e6,'grid50_area_km2':len(ds50)*2500/1e6}
  results[scope]=s
  covered=shapely.intersection(mask,service(hi));uncovered=shapely.difference(mask,service(hi))
  assert cover(lo)<.85<=cover(hi) and hi-lo<1 and abs(guess-hi)<10
  assert abs(knee['coverage_grid']-knee['coverage_exact'])<.005
  assert abs(covered.area+uncovered.area-mask.area)<.1
  for status,g in [('covered',covered),('uncovered',uncovered)]:
   polygons.append({'type':'Feature','properties':{'scope':scope,'status':status,'radius_m':hi,'area_km2':g.area/1e6,'area_fraction':g.area/mask.area},'geometry':mapping(transform(TO_LL,g))})
  step=250 if scope=='all' else 100;dv,vxy=grid_distances(mask,tree,step,True);lon,lat=TO_LL(vxy[:,0],vxy[:,1])
  scopes[scope]={'summary':s,'cells':[[round(float(a),5),round(float(b),5),round(float(c))] for a,b,c in zip(lon,lat,dv)],'display_grid_m':step,
   'points':[{'name':f['properties']['name'],'district':f['properties']['district'],'address':f['properties']['address'],'xy':f['geometry']['coordinates'],'site_id':f['properties']['id'],
    'elder_same_address':f['properties'].get('elder_registered_colocation',False),
    'note':('老年学校目录登记同址：'+'、'.join(f['properties'].get('elder_school_names',[]))+'；当前入驻需核实。' if f['properties'].get('elder_registered_colocation') else '')+f['properties']['note']} for f in good]}
  upper=max(10000,math.ceil(float(np.quantile(ds25,.99))/25)*25)
  plots.append({'layer':'culture','name':'社区文化活动中心','scope_id':scope,'scope_name':'全上海16区' if scope=='all' else '仅中心七区','main_candidate':knee,'endpoint_sensitivity':sensitivity,'existing_r85_m':hi,
   'curve':[[int(r),float(np.searchsorted(sorted_d,r,side='right')/len(sorted_d))] for r in np.arange(0,upper+1,25)]})
  print(json.dumps({k:s[k] for k in ['scope','registry_count','included_count','r85_m','knee_m','knee_coverage']},ensure_ascii=False),flush=True)
 write(HERE/'analysis.json',{'results':results,'registry_source_url':REGISTRY_URL,'registry_date':'2026-08-18','point_capture_date':'2026-10-21','residential_source':'../社区食堂地图/residential.geojson','exclusions':[f['properties'] for f in fs if not f['properties']['included']]})
 write(HERE/'coverage_r85.geojson',{'type':'FeatureCollection','features':polygons})
 write(ROOT/'tmp'/'culture_map_data.json',{'districts':DISTRICTS,'scopes':scopes})
 write(ROOT/'tmp'/'culture_tradeoff_plot_data.json',plots)
if __name__=='__main__':analyze()
