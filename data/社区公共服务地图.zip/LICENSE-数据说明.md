# 数据和许可说明

- 设施点位和居住用地来自 OpenStreetMap，© OpenStreetMap contributors，按 ODbL 1.0 许可（https://www.openstreetmap.org/copyright）。由它派生的 geojson 和 json 结果同样适用 ODbL。
- 设施名录来自上海市民政局、上海图书馆、上海公共体育设施平台、上海市文化和旅游局、上海市卫生健康委员会等公开页面，链接见各目录的分析说明。
- 覆盖率是本组测算：直线距离、已标注居住用地面积口径，不是官方统计，也不是 15 分钟步行可达率。
